﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Odbc;
using System.Diagnostics;

namespace Project2
{
    class Database
    {
        OdbcConnection dbConn;
        OdbcCommand dbCmd;
        OdbcDataReader dbReader;

        List<int> ids;

        public Database()
        {
            dbConn = new OdbcConnection("Driver={SQL Server};"
                + "Server=scb-sv-mgis-4.main.ad.rit.edu\\mgismssql;"
                + "DataBase=MGIS350_2181_Group5;"
                + "Uid=Group5;"
                + "Pwd=qqelnrkz&%6082FPEH");

            ids = new List<int>();
        }

        private  void ExecuteQuery(string Query)
        {
            try
            {
                Debug.WriteLine("");
                Debug.WriteLine("SQL Query: " + Query);
                Debug.WriteLine("");
                
                // Building command to database and executing the query string 
                dbCmd = new OdbcCommand(Query, dbConn);
                // Opening the connection
                dbConn.Open();
                // Executing the query and closing the connection
                dbReader = dbCmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                // Determine if database is open.  If so close it.
                if (dbConn.State.ToString() == "Open")
                {
                    this.CloseDatabase();
                }
                // Display Error
                System.Windows.Forms.MessageBox.Show("Error:\n\n" + ex.ToString() + "\n");
            }
        }

        private void CloseDatabase()
        {
            // Determine if database is open.  If so close it.
            if (dbConn.State.ToString() == "Open")
            {
                // Closing connection
                dbConn.Close();
            }
        }

        public void DisplayTransaction( System.Windows.Forms.ListBox output)
        {
            //clear the current output
            output.Items.Clear();
            ids.Clear();

            // build our query to display the selected transactions

            string query = "SELECT * FROM p3Invoices;";
            ExecuteQuery(query);

            //LOOp through the query

            int i = 1;
            while (dbReader.Read())
            {               
                if (dbReader.IsDBNull(0) == false)
                {                   
                    output.Items.Add("Invoice "+i+ " ordered on " + dbReader["orderdt"]);
                    ids.Add(Convert.ToInt32(dbReader["id"]));
                    i++;
                }
            }
            CloseDatabase();
        }

        public void ShowDetail(int input, System .Windows.Forms .ListBox output)
        {
            output.Items.Clear();

            string Query = "select lineItem from dbo.p3LineItems where invoiceId =" +ids[input] + ";";
            ExecuteQuery(Query);
            // show the detail to listbox
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    output.Items.Add(dbReader["lineItem"]);
                }
            }
            CloseDatabase();
        }
        
        public int Addtransaction()
        {
            string Query = "insert into dbo.p3Invoices(orderdt) output inserted.id values(Getdate());";
            ExecuteQuery(Query);
            int id=1;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    id = Convert.ToInt32(dbReader["id"]);
                }
            }
            CloseDatabase();
            return id;
        }

        public void Addtoitems(System.Windows.Forms.ListBox output,int id)  //is the basis transaction's box
        {
            for (int i = 0; i < output .Items .Count ; i++)
            {
                string Query = "insert into dbo.p3LineItems(invoiceId,lineItem) values("+id+",'"+output.Items[i]+"');";
                ExecuteQuery(Query);
                CloseDatabase();  
            }
                     
        }

        public void UpdateInv(decimal S,decimal B,decimal H,decimal M,int Small, int Lar)
        {
            string Query = "update p3Inventory set strawberries=" + S + ",bananas=" + B + ",honey=" + H + ",milk=" + M + ",smallcups=" + Small + ",largecups=" + Lar + " where id=1;";
            ExecuteQuery(Query);
            CloseDatabase();
        }

        public void Updateprofit(decimal sale, decimal expense)
        {
            string Query = "update p3Profits set sales=" + sale + ",expenses=" + expense + ";";
            ExecuteQuery(Query);
            CloseDatabase();
        }
        public decimal StrawUp()
        {
           
            string Query = "select strawberries from p3Inventory; ";
            ExecuteQuery(Query);
            decimal straw=0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                     straw= Convert .ToDecimal( dbReader["strawberries"]);
                }
            }
            CloseDatabase();
            return straw;
        }
        public decimal BanUp()
        {
            string Query = "select bananas from p3Inventory; ";
            ExecuteQuery(Query);
            decimal bana = 0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    bana = Convert.ToDecimal(dbReader["bananas"]);
                }
            }
            CloseDatabase();
            return  bana;
        }
        public decimal honeyUp()
        {
            string Query = "select honey from p3Inventory; ";
            ExecuteQuery(Query);
            decimal honey = 0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                   honey= Convert.ToDecimal(dbReader["honey"]);
                }
            }
            CloseDatabase();
            return honey;
        }
        public decimal milkUp()
        {
            string Query = "select milk from p3Inventory; ";
            ExecuteQuery(Query);
            decimal milk = 0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    milk= Convert.ToDecimal(dbReader["milk"]);
                }
            }
            CloseDatabase();
            return milk;
        }
        public int smallcupsUp()
        {
            string Query = "select smallcups from p3Inventory; ";
            ExecuteQuery(Query);
            int smallcups = 0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    smallcups = Convert.ToInt32 (dbReader["smallcups"]);
                }
            }
            CloseDatabase();
            return smallcups;
        }
        public int largecupsUp()
        {
            string Query = "select largecups from p3Inventory; ";
            ExecuteQuery(Query);
            int largecups = 0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    largecups = Convert.ToInt32(dbReader["largecups"]);
                }
            }
            CloseDatabase();
            return largecups;
        }
        public decimal salesUp()
        {
            string Query = "select sales from p3Profits;";
            ExecuteQuery(Query);
            decimal sales=0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    sales= Convert.ToDecimal (dbReader["sales"]);
                }
            }
            CloseDatabase();
            return sales;
        }
        public decimal expensesUp()
        {
            string Query = "select expenses from p3Profits; ";
            ExecuteQuery(Query);
            decimal expenses=0;
            while (dbReader.Read())
            {
                if (dbReader.IsDBNull(0) == false)
                {
                    expenses = Convert.ToDecimal(dbReader["expenses"]);
                }
            }
            CloseDatabase();
            return expenses;
        }

    }
}
