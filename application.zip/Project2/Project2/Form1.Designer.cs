﻿namespace Project2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.nudQuantity = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoLargeCup = new System.Windows.Forms.RadioButton();
            this.rdoSmallCup = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.chkHoney = new System.Windows.Forms.CheckBox();
            this.listBox = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnStrawberries = new System.Windows.Forms.Button();
            this.btnBananas = new System.Windows.Forms.Button();
            this.btnHoney = new System.Windows.Forms.Button();
            this.btnMilk = new System.Windows.Forms.Button();
            this.btnSmallCups = new System.Windows.Forms.Button();
            this.btnLargeCups = new System.Windows.Forms.Button();
            this.lblStrawberries = new System.Windows.Forms.Label();
            this.lblBananas = new System.Windows.Forms.Label();
            this.lblHoney = new System.Windows.Forms.Label();
            this.lblMilk = new System.Windows.Forms.Label();
            this.lblSmallCups = new System.Windows.Forms.Label();
            this.lblLargeCups = new System.Windows.Forms.Label();
            this.lblExpenses = new System.Windows.Forms.Label();
            this.lblSales = new System.Windows.Forms.Label();
            this.lblProfit = new System.Windows.Forms.Label();
            this.chkStrawberries = new System.Windows.Forms.CheckBox();
            this.chkBananas = new System.Windows.Forms.CheckBox();
            this.submit = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.OldTran = new System.Windows.Forms.ListBox();
            this.Detail = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(555, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Strawberry";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(558, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Banana";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(558, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Honey";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(559, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Milk";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(558, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Small Cup";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(559, 264);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Large Cup";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(539, 334);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Total Expense:";
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Location = new System.Drawing.Point(12, 254);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(177, 32);
            this.btnPlaceOrder.TabIndex = 17;
            this.btnPlaceOrder.Text = "&Add To Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // nudQuantity
            // 
            this.nudQuantity.Location = new System.Drawing.Point(25, 208);
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new System.Drawing.Size(136, 20);
            this.nudQuantity.TabIndex = 18;
            this.nudQuantity.ValueChanged += new System.EventHandler(this.chkStrawberries_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoLargeCup);
            this.groupBox1.Controls.Add(this.rdoSmallCup);
            this.groupBox1.Location = new System.Drawing.Point(12, 117);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(151, 72);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            // 
            // rdoLargeCup
            // 
            this.rdoLargeCup.AutoSize = true;
            this.rdoLargeCup.Location = new System.Drawing.Point(13, 48);
            this.rdoLargeCup.Name = "rdoLargeCup";
            this.rdoLargeCup.Size = new System.Drawing.Size(74, 17);
            this.rdoLargeCup.TabIndex = 1;
            this.rdoLargeCup.TabStop = true;
            this.rdoLargeCup.Text = "Large Cup";
            this.rdoLargeCup.UseVisualStyleBackColor = true;
            this.rdoLargeCup.CheckedChanged += new System.EventHandler(this.chkStrawberries_CheckedChanged);
            // 
            // rdoSmallCup
            // 
            this.rdoSmallCup.AutoSize = true;
            this.rdoSmallCup.Location = new System.Drawing.Point(13, 16);
            this.rdoSmallCup.Name = "rdoSmallCup";
            this.rdoSmallCup.Size = new System.Drawing.Size(72, 17);
            this.rdoSmallCup.TabIndex = 0;
            this.rdoSmallCup.TabStop = true;
            this.rdoSmallCup.Text = "Small Cup";
            this.rdoSmallCup.UseVisualStyleBackColor = true;
            this.rdoSmallCup.CheckedChanged += new System.EventHandler(this.chkStrawberries_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(680, 334);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Total Sales:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(539, 362);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Total Profits:";
            // 
            // chkHoney
            // 
            this.chkHoney.AutoSize = true;
            this.chkHoney.Location = new System.Drawing.Point(27, 94);
            this.chkHoney.Name = "chkHoney";
            this.chkHoney.Size = new System.Drawing.Size(57, 17);
            this.chkHoney.TabIndex = 28;
            this.chkHoney.Text = "Honey";
            this.chkHoney.UseVisualStyleBackColor = true;
            this.chkHoney.CheckedChanged += new System.EventHandler(this.chkStrawberries_CheckedChanged);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(542, 477);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(266, 82);
            this.listBox.TabIndex = 30;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(539, 448);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 31;
            this.label10.Text = "Transaction:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "Order:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(558, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "Inventory:";
            // 
            // btnStrawberries
            // 
            this.btnStrawberries.Location = new System.Drawing.Point(664, 47);
            this.btnStrawberries.Name = "btnStrawberries";
            this.btnStrawberries.Size = new System.Drawing.Size(80, 34);
            this.btnStrawberries.TabIndex = 34;
            this.btnStrawberries.Text = "Add More";
            this.btnStrawberries.UseVisualStyleBackColor = true;
            this.btnStrawberries.Click += new System.EventHandler(this.btnStrawberries_Click);
            // 
            // btnBananas
            // 
            this.btnBananas.Location = new System.Drawing.Point(664, 84);
            this.btnBananas.Name = "btnBananas";
            this.btnBananas.Size = new System.Drawing.Size(79, 38);
            this.btnBananas.TabIndex = 35;
            this.btnBananas.Text = "Add More";
            this.btnBananas.UseVisualStyleBackColor = true;
            this.btnBananas.Click += new System.EventHandler(this.btnBananas_Click);
            // 
            // btnHoney
            // 
            this.btnHoney.Location = new System.Drawing.Point(664, 131);
            this.btnHoney.Name = "btnHoney";
            this.btnHoney.Size = new System.Drawing.Size(80, 26);
            this.btnHoney.TabIndex = 36;
            this.btnHoney.Text = "Add More";
            this.btnHoney.UseVisualStyleBackColor = true;
            this.btnHoney.Click += new System.EventHandler(this.btnHoney_Click);
            // 
            // btnMilk
            // 
            this.btnMilk.Location = new System.Drawing.Point(664, 176);
            this.btnMilk.Name = "btnMilk";
            this.btnMilk.Size = new System.Drawing.Size(79, 26);
            this.btnMilk.TabIndex = 37;
            this.btnMilk.Text = "Add More";
            this.btnMilk.UseVisualStyleBackColor = true;
            this.btnMilk.Click += new System.EventHandler(this.btnMilk_Click);
            // 
            // btnSmallCups
            // 
            this.btnSmallCups.Location = new System.Drawing.Point(664, 218);
            this.btnSmallCups.Name = "btnSmallCups";
            this.btnSmallCups.Size = new System.Drawing.Size(80, 24);
            this.btnSmallCups.TabIndex = 38;
            this.btnSmallCups.Text = "Add More";
            this.btnSmallCups.UseVisualStyleBackColor = true;
            this.btnSmallCups.Click += new System.EventHandler(this.btnSmallCups_Click);
            // 
            // btnLargeCups
            // 
            this.btnLargeCups.Location = new System.Drawing.Point(664, 259);
            this.btnLargeCups.Name = "btnLargeCups";
            this.btnLargeCups.Size = new System.Drawing.Size(79, 23);
            this.btnLargeCups.TabIndex = 39;
            this.btnLargeCups.Text = "Add More";
            this.btnLargeCups.UseVisualStyleBackColor = true;
            this.btnLargeCups.Click += new System.EventHandler(this.btnLargeCups_Click);
            // 
            // lblStrawberries
            // 
            this.lblStrawberries.AutoSize = true;
            this.lblStrawberries.Location = new System.Drawing.Point(616, 55);
            this.lblStrawberries.Name = "lblStrawberries";
            this.lblStrawberries.Size = new System.Drawing.Size(13, 13);
            this.lblStrawberries.TabIndex = 40;
            this.lblStrawberries.Text = "0";
            // 
            // lblBananas
            // 
            this.lblBananas.AutoSize = true;
            this.lblBananas.Location = new System.Drawing.Point(616, 92);
            this.lblBananas.Name = "lblBananas";
            this.lblBananas.Size = new System.Drawing.Size(13, 13);
            this.lblBananas.TabIndex = 41;
            this.lblBananas.Text = "0";
            // 
            // lblHoney
            // 
            this.lblHoney.AutoSize = true;
            this.lblHoney.Location = new System.Drawing.Point(616, 138);
            this.lblHoney.Name = "lblHoney";
            this.lblHoney.Size = new System.Drawing.Size(13, 13);
            this.lblHoney.TabIndex = 42;
            this.lblHoney.Text = "0";
            // 
            // lblMilk
            // 
            this.lblMilk.AutoSize = true;
            this.lblMilk.Location = new System.Drawing.Point(614, 183);
            this.lblMilk.Name = "lblMilk";
            this.lblMilk.Size = new System.Drawing.Size(13, 13);
            this.lblMilk.TabIndex = 43;
            this.lblMilk.Text = "0";
            // 
            // lblSmallCups
            // 
            this.lblSmallCups.AutoSize = true;
            this.lblSmallCups.Location = new System.Drawing.Point(616, 225);
            this.lblSmallCups.MaximumSize = new System.Drawing.Size(100, 100);
            this.lblSmallCups.Name = "lblSmallCups";
            this.lblSmallCups.Size = new System.Drawing.Size(13, 13);
            this.lblSmallCups.TabIndex = 44;
            this.lblSmallCups.Text = "0";
            // 
            // lblLargeCups
            // 
            this.lblLargeCups.AutoSize = true;
            this.lblLargeCups.Location = new System.Drawing.Point(616, 266);
            this.lblLargeCups.MaximumSize = new System.Drawing.Size(100, 100);
            this.lblLargeCups.Name = "lblLargeCups";
            this.lblLargeCups.Size = new System.Drawing.Size(13, 13);
            this.lblLargeCups.TabIndex = 45;
            this.lblLargeCups.Text = "0";
            // 
            // lblExpenses
            // 
            this.lblExpenses.AutoSize = true;
            this.lblExpenses.Location = new System.Drawing.Point(618, 334);
            this.lblExpenses.Name = "lblExpenses";
            this.lblExpenses.Size = new System.Drawing.Size(34, 13);
            this.lblExpenses.TabIndex = 46;
            this.lblExpenses.Text = "$0.00";
            // 
            // lblSales
            // 
            this.lblSales.AutoSize = true;
            this.lblSales.Location = new System.Drawing.Point(749, 334);
            this.lblSales.Name = "lblSales";
            this.lblSales.Size = new System.Drawing.Size(34, 13);
            this.lblSales.TabIndex = 47;
            this.lblSales.Text = "$0.00";
            // 
            // lblProfit
            // 
            this.lblProfit.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblProfit.Location = new System.Drawing.Point(614, 362);
            this.lblProfit.Name = "lblProfit";
            this.lblProfit.Size = new System.Drawing.Size(45, 13);
            this.lblProfit.TabIndex = 48;
            this.lblProfit.Text = "$0.00";
            // 
            // chkStrawberries
            // 
            this.chkStrawberries.AutoSize = true;
            this.chkStrawberries.Location = new System.Drawing.Point(28, 47);
            this.chkStrawberries.Name = "chkStrawberries";
            this.chkStrawberries.Size = new System.Drawing.Size(76, 17);
            this.chkStrawberries.TabIndex = 49;
            this.chkStrawberries.Text = "Strawberry";
            this.chkStrawberries.UseVisualStyleBackColor = true;
            this.chkStrawberries.CheckedChanged += new System.EventHandler(this.chkStrawberries_CheckedChanged);
            // 
            // chkBananas
            // 
            this.chkBananas.AutoSize = true;
            this.chkBananas.Location = new System.Drawing.Point(27, 70);
            this.chkBananas.Name = "chkBananas";
            this.chkBananas.Size = new System.Drawing.Size(63, 17);
            this.chkBananas.TabIndex = 50;
            this.chkBananas.Text = "Banana";
            this.chkBananas.UseVisualStyleBackColor = true;
            this.chkBananas.CheckedChanged += new System.EventHandler(this.chkStrawberries_CheckedChanged);
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(538, 387);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(120, 36);
            this.submit.TabIndex = 51;
            this.submit.Text = "Place Order";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(683, 389);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(99, 34);
            this.btnRemove.TabIndex = 52;
            this.btnRemove.Text = "Cancel Order";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // OldTran
            // 
            this.OldTran.FormattingEnabled = true;
            this.OldTran.Location = new System.Drawing.Point(28, 334);
            this.OldTran.Name = "OldTran";
            this.OldTran.Size = new System.Drawing.Size(242, 95);
            this.OldTran.TabIndex = 53;
            this.OldTran.SelectedIndexChanged += new System.EventHandler(this.OldTran_SelectedIndexChanged);
            // 
            // Detail
            // 
            this.Detail.FormattingEnabled = true;
            this.Detail.Location = new System.Drawing.Point(25, 464);
            this.Detail.Name = "Detail";
            this.Detail.Size = new System.Drawing.Size(245, 95);
            this.Detail.TabIndex = 54;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(29, 313);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(95, 13);
            this.label13.TabIndex = 55;
            this.label13.Text = "Transaction Order:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(25, 448);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 13);
            this.label14.TabIndex = 56;
            this.label14.Text = "Order Detail:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 593);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Detail);
            this.Controls.Add(this.OldTran);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.chkBananas);
            this.Controls.Add(this.chkStrawberries);
            this.Controls.Add(this.lblProfit);
            this.Controls.Add(this.lblSales);
            this.Controls.Add(this.lblExpenses);
            this.Controls.Add(this.lblLargeCups);
            this.Controls.Add(this.lblSmallCups);
            this.Controls.Add(this.lblMilk);
            this.Controls.Add(this.lblHoney);
            this.Controls.Add(this.lblBananas);
            this.Controls.Add(this.lblStrawberries);
            this.Controls.Add(this.btnLargeCups);
            this.Controls.Add(this.btnSmallCups);
            this.Controls.Add(this.btnMilk);
            this.Controls.Add(this.btnHoney);
            this.Controls.Add(this.btnBananas);
            this.Controls.Add(this.btnStrawberries);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.chkHoney);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.nudQuantity);
            this.Controls.Add(this.btnPlaceOrder);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnPlaceOrder;
        private System.Windows.Forms.NumericUpDown nudQuantity;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoLargeCup;
        private System.Windows.Forms.RadioButton rdoSmallCup;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chkHoney;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnStrawberries;
        private System.Windows.Forms.Button btnBananas;
        private System.Windows.Forms.Button btnHoney;
        private System.Windows.Forms.Button btnMilk;
        private System.Windows.Forms.Button btnSmallCups;
        private System.Windows.Forms.Button btnLargeCups;
        private System.Windows.Forms.Label lblStrawberries;
        private System.Windows.Forms.Label lblBananas;
        private System.Windows.Forms.Label lblHoney;
        private System.Windows.Forms.Label lblMilk;
        private System.Windows.Forms.Label lblSmallCups;
        private System.Windows.Forms.Label lblLargeCups;
        private System.Windows.Forms.Label lblExpenses;
        private System.Windows.Forms.Label lblSales;
        private System.Windows.Forms.Label lblProfit;
        private System.Windows.Forms.CheckBox chkStrawberries;
        private System.Windows.Forms.CheckBox chkBananas;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.ListBox OldTran;
        private System.Windows.Forms.ListBox Detail;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
    }
}

